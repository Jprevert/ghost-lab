A Pen created at CodePen.io. You can find this one at https://codepen.io/dhanushbadge/pen/olsvi.

 This is pure HTML5 CSS3 Horizontal Menu. It requires no javascript or programming language to function. This was found on Google, further enhancements were made in css & is now published by me as a 'take-away' code.
Note that the transation effect does not validate in W3C Validation, so you can get rid of the those CSS styles to validate your document.